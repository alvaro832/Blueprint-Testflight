import { useEffect, useRef, useState } from "react";
import { optimize, optimizeAuto, costBreakdown, type OptimizeResult, type CostRow, type ContextInfo } from "../lib/optimizer";
import { captureSelection, replaceSelection, copyText, hideFloating, addHistory, isTauri } from "../lib/bridge";
import { useStore } from "../lib/store";
import { money, num } from "../lib/format";
import ResultView from "../components/ResultView";
import { Spinner } from "../components/ui";

/**
 * Frameless glass overlay opened by the global hotkey. Auto-captures the selection and
 * (in Auto mode) detects context — code, JSON, email, notes, prompt, markdown, document —
 * then optimizes with the right mode. Keyboard-first, screen-reader labelled, reduced-motion
 * aware. Toolbar: Auto · Optimize · Compress · Reduce · Estimate Cost · Rewrite + Copy/Replace/Export.
 */
type Action = "auto" | "optimize" | "compress" | "reduce" | "cost" | "clearer";

const ACTIONS: { id: Action; label: string }[] = [
  { id: "auto", label: "Auto" },
  { id: "optimize", label: "Optimize" },
  { id: "compress", label: "Compress" },
  { id: "reduce", label: "Reduce" },
  { id: "cost", label: "Estimate Cost" },
  { id: "clearer", label: "Rewrite" },
];

export default function Floating() {
  const { settings } = useStore();
  const [text, setText] = useState("");
  const [action, setAction] = useState<Action>("auto");
  const [result, setResult] = useState<OptimizeResult | null>(null);
  const [detected, setDetected] = useState<ContextInfo | null>(null);
  const [cost, setCost] = useState<{ tokens: number; rows: CostRow[] } | null>(null);
  const [busy, setBusy] = useState(true);
  const [note, setNote] = useState("");
  const taRef = useRef<HTMLTextAreaElement>(null);

  function run(t: string, a: Action) {
    if (!t.trim()) { setBusy(false); setResult(null); setCost(null); setDetected(null); return; }
    setBusy(true);
    setTimeout(() => {
      if (a === "cost") {
        setCost(costBreakdown(t, Math.min(1500, Math.round(t.length / 8) || 200)));
        setResult(null); setDetected(null);
      } else if (a === "auto") {
        const res = optimizeAuto(t, settings.defaultModelId, settings.monthlyRuns);
        setResult(res); setDetected(res.detected); setCost(null);
        record(res, t);
      } else {
        const level = a === "compress" ? "aggressive" : a === "reduce" ? "reduce" : a === "clearer" ? "clarity" : settings.level;
        const res = optimize(t, { modelId: settings.defaultModelId, monthlyRuns: settings.monthlyRuns, level });
        setResult(res); setDetected(null); setCost(null);
        record(res, t);
      }
      setBusy(false);
      if (settings.autoCopy) copyResult(true);
    }, 30);
  }

  function record(res: OptimizeResult, t: string) {
    addHistory({
      created_at: Date.now(), source: "floating", model_id: settings.defaultModelId,
      original_tokens: res.originalTokens, optimized_tokens: res.optimizedTokens,
      saved_usd: res.savedPerCall, quality_risk: res.qualityRisk, preview: t.slice(0, 80),
    }).catch(() => {});
  }

  async function loadSelection() {
    setBusy(true);
    const sel = await captureSelection();
    if (sel.trim()) { setText(sel); run(sel, action); }
    else { setText(""); setBusy(false); taRef.current?.focus(); }
  }

  useEffect(() => {
    loadSelection();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") hideFloating();
      if ((e.metaKey || e.ctrlKey) && e.key === "Enter") run(text, action); // re-run
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function pick(a: Action) { setAction(a); run(text, a); }

  async function copyResult(silent = false) {
    const out = result?.optimized ?? "";
    if (!out) return;
    await copyText(out);
    if (!silent) { setNote("Copied"); setTimeout(() => setNote(""), 1400); }
  }
  async function doReplace() {
    const out = result?.optimized ?? "";
    if (!out) return;
    await replaceSelection(out);
    hideFloating();
  }
  function doExport() {
    const payload = result ?? cost;
    if (!payload) return;
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "blueprint-result.json"; a.click();
    URL.revokeObjectURL(url);
    setNote("Exported"); setTimeout(() => setNote(""), 1400);
  }

  return (
    <div
      role="dialog"
      aria-label="Blueprint optimizer"
      className="bp-overlay h-screen flex flex-col bg-ink-900/80 backdrop-blur-xl border border-white/10 rounded-2xl overflow-hidden shadow-2xl"
    >
      <div className="flex items-center gap-2 px-3 py-2 border-b border-white/10" data-tauri-drag-region>
        <div className="w-5 h-5 rounded bg-gradient-to-br from-brand to-gold grid place-items-center text-white font-black text-[10px]" aria-hidden>B</div>
        <span className="text-xs font-bold">Blueprint</span>
        <span className="text-[10px] text-slate-500 ml-1">{settings.shortcut || "Ctrl/Cmd+Shift+B"}</span>
        <button className="ml-auto text-slate-500 hover:text-ink-100 text-sm" aria-label="Close" onClick={() => hideFloating()}>✕</button>
      </div>

      <div className="grid grid-cols-6 gap-1 px-2 pt-2" role="tablist" aria-label="Optimization mode">
        {ACTIONS.map((a) => (
          <button
            key={a.id}
            role="tab"
            aria-selected={action === a.id}
            onClick={() => pick(a.id)}
            className={"text-[10px] px-1 py-1.5 rounded font-semibold transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-brand " +
              (action === a.id ? "bg-brand text-white" : "bg-ink-800 text-slate-400 hover:text-ink-100")}
          >
            {a.label}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-auto p-3">
        <textarea
          ref={taRef}
          aria-label="Text to optimize"
          className="field font-mono text-xs min-h-[60px] mb-2 bg-ink-900/60"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Highlighted text appears here…"
        />
        {detected && action === "auto" && (
          <div className="text-[11px] text-brand mb-2" aria-live="polite">Detected: {detected.label}</div>
        )}

        {busy ? (
          <div className="py-6 flex justify-center"><Spinner label="Working…" /></div>
        ) : !text.trim() ? (
          <div className="text-center text-xs text-slate-500 py-6">
            {isTauri() ? "Highlight text in any app, then press the hotkey." : "Paste text above and choose an action."}
          </div>
        ) : action === "cost" && cost ? (
          <CostTable data={cost} />
        ) : result ? (
          <ResultView result={result} monthlyRuns={settings.monthlyRuns} compact />
        ) : null}
      </div>

      <div className="flex gap-2 p-3 border-t border-white/10">
        <button className="btn !py-1.5 flex-1 text-xs" disabled={!result} onClick={() => copyResult()}>{note === "Copied" ? "Copied ✓" : "Copy Result"}</button>
        <button className="btn btn-primary !py-1.5 flex-1 text-xs" disabled={!result} onClick={doReplace}>Replace Selected Text</button>
        <button className="btn !py-1.5 text-xs" disabled={!result && !cost} onClick={doExport} aria-label="Export result as JSON">{note === "Exported" ? "✓" : "Export"}</button>
      </div>
    </div>
  );
}

function CostTable({ data }: { data: { tokens: number; rows: CostRow[] } }) {
  return (
    <div>
      <div className="text-xs text-slate-400 mb-2">
        This text is <b className="text-ink-100">{num(data.tokens)} input tokens</b>. Cost to send, cheapest first:
      </div>
      <table className="w-full text-xs">
        <thead>
          <tr className="text-left text-slate-500 border-b border-line">
            <th className="py-1.5 font-semibold">Model</th>
            <th className="py-1.5 font-semibold">Input</th>
            <th className="py-1.5 font-semibold">+ output</th>
          </tr>
        </thead>
        <tbody>
          {data.rows.map((r) => (
            <tr key={r.model.id} className="border-b border-line/40">
              <td className="py-1.5 font-semibold">{r.model.name}</td>
              <td className="py-1.5">{money(r.inputCost)}</td>
              <td className="py-1.5 text-slate-300">{money(r.totalCost)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
