import { useEffect, useState } from "react";
import { useStore } from "../lib/store";
import { clearHistory } from "../lib/bridge";
import { money, num, timeAgo } from "../lib/format";
import { Card, Empty, Badge, Toast } from "../components/ui";

export default function History() {
  const { history, refreshHistory } = useStore();
  const [q, setQ] = useState("");
  const [toast, setToast] = useState("");
  useEffect(() => { refreshHistory(); }, [refreshHistory]);

  const rows = history.filter((h) => h.preview.toLowerCase().includes(q.toLowerCase()));

  return (
    <div>
      <header className="mb-5 flex items-end justify-between">
        <div>
          <h1 className="text-2xl font-serif font-medium tracking-tight">History</h1>
          <p className="text-sm text-slate-400 mt-0.5">Every optimization, stored locally on your machine.</p>
        </div>
        {history.length > 0 && (
          <button className="btn text-bad" onClick={async () => { await clearHistory(); await refreshHistory(); setToast("History cleared"); }}>
            Clear history
          </button>
        )}
      </header>

      {history.length === 0 ? (
        <Card><Empty title="No history yet" hint="Optimizations you run will be listed here with their savings." icon="◷" /></Card>
      ) : (
        <Card>
          <input className="field mb-3" placeholder="Search by content…" value={q} onChange={(e) => setQ(e.target.value)} />
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs text-slate-500 border-b border-line">
                <th className="py-2 font-semibold">When</th>
                <th className="py-2 font-semibold">Source</th>
                <th className="py-2 font-semibold">Preview</th>
                <th className="py-2 font-semibold">Tokens</th>
                <th className="py-2 font-semibold">Saved</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((h) => (
                <tr key={h.id} className="border-b border-line/50 align-top">
                  <td className="py-2 text-slate-400 whitespace-nowrap">{timeAgo(h.created_at)}</td>
                  <td className="py-2"><Badge tone="muted">{h.source}</Badge></td>
                  <td className="py-2 text-slate-300 max-w-xs truncate">{h.preview}</td>
                  <td className="py-2 whitespace-nowrap">{num(h.original_tokens)} → <span className="text-good">{num(h.optimized_tokens)}</span></td>
                  <td className="py-2 text-good font-semibold whitespace-nowrap">{money(h.saved_usd)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {rows.length === 0 && <div className="text-xs text-slate-500 py-4 text-center">No matches.</div>}
        </Card>
      )}
      {toast && <Toast msg={toast} onDone={() => setToast("")} />}
    </div>
  );
}
