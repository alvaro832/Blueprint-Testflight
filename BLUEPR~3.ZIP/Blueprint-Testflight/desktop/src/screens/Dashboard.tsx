import { useEffect } from "react";
import { useStore } from "../lib/store";
import { money, num, timeAgo } from "../lib/format";
import { Stat, Card, Empty, Badge } from "../components/ui";
import { useNavigate } from "react-router-dom";

export default function Dashboard() {
  const { history, totalSaved, refreshHistory } = useStore();
  const navigate = useNavigate();
  useEffect(() => { refreshHistory(); }, [refreshHistory]);

  const totalTokensSaved = history.reduce((s, h) => s + Math.max(0, h.original_tokens - h.optimized_tokens), 0);
  const avgComp = history.length
    ? Math.round(history.reduce((s, h) => s + (h.original_tokens ? (1 - h.optimized_tokens / h.original_tokens) * 100 : 0), 0) / history.length)
    : 0;

  return (
    <div>
      <header className="mb-5 flex items-end justify-between">
        <div>
          <h1 className="text-2xl font-serif font-medium tracking-tight">Dashboard</h1>
          <p className="text-sm text-slate-400 mt-0.5">Your AI savings at a glance.</p>
        </div>
        <button className="btn btn-primary" onClick={() => navigate("/optimize")}>✦ Optimize Prompt</button>
      </header>

      <div className="mb-4">
        <Card className="bg-gradient-to-br from-brand-soft to-ink-850 border-brand/30">
          <div className="text-xs font-semibold text-slate-300">Total AI cost saved</div>
          <div className="text-5xl font-black tracking-tight text-good mt-1">{money(totalSaved)}</div>
          <div className="text-xs text-slate-400 mt-1">across {num(history.length)} optimizations · {num(totalTokensSaved)} tokens trimmed</div>
        </Card>
      </div>

      <div className="grid grid-cols-3 gap-3 mb-5">
        <Stat label="Optimizations" value={num(history.length)} accent="brand" />
        <Stat label="Avg. compression" value={avgComp + "%"} accent="good" />
        <Stat label="Tokens trimmed" value={num(totalTokensSaved)} accent="gold" />
      </div>

      <Card>
        <h3 className="text-sm font-semibold mb-3">Recent activity</h3>
        {history.length === 0 ? (
          <Empty title="No optimizations yet" hint="Head to Optimize and paste a prompt to see your savings build up here." icon="📈" />
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs text-slate-500 border-b border-line">
                <th className="py-2 font-semibold">When</th>
                <th className="py-2 font-semibold">Source</th>
                <th className="py-2 font-semibold">Tokens</th>
                <th className="py-2 font-semibold">Saved</th>
                <th className="py-2 font-semibold">Risk</th>
              </tr>
            </thead>
            <tbody>
              {history.slice(0, 8).map((h) => (
                <tr key={h.id} className="border-b border-line/50">
                  <td className="py-2 text-slate-400">{timeAgo(h.created_at)}</td>
                  <td className="py-2"><Badge tone="muted">{h.source}</Badge></td>
                  <td className="py-2">{num(h.original_tokens)} → <span className="text-good">{num(h.optimized_tokens)}</span></td>
                  <td className="py-2 text-good font-semibold">{money(h.saved_usd)}</td>
                  <td className="py-2">{h.quality_risk}/100</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>
    </div>
  );
}
