import { useMemo, useState } from "react";
import { routeTask, TIER_LABEL } from "../lib/pricing";
import { money } from "../lib/format";
import { Card, Badge } from "../components/ui";

const PRESETS: Record<string, [string, number, number]> = {
  Classification: ["Classify a short support ticket into one of four labels. Return only the label.", 600, 15],
  Summarization: ["Summarize a 3-page document into 5 bullet points.", 3000, 180],
  "Code review": ["Review a Python pull request for bugs, security issues and style, with reasoning and fixes.", 6000, 1200],
  "Contract analysis": ["Analyze a 40-page commercial contract for liability risk and draft a negotiation memo with citations.", 45000, 2500],
};

export default function ModelRouter() {
  const [task, setTask] = useState(PRESETS["Classification"][0]);
  const [inTok, setInTok] = useState(600);
  const [outTok, setOutTok] = useState(15);
  const r = useMemo(() => routeTask(task, inTok, outTok), [task, inTok, outTok]);
  const barColor = r.score < 25 ? "bg-good" : r.score < 50 ? "bg-brand" : r.score < 75 ? "bg-warn" : "bg-bad";

  return (
    <div>
      <header className="mb-5">
        <h1 className="text-2xl font-serif font-medium tracking-tight">Model Router</h1>
        <p className="text-sm text-slate-400 mt-0.5">Describe a task — Blueprint scores its difficulty and finds the cheapest capable model.</p>
      </header>

      <div className="grid grid-cols-2 gap-4 mb-4">
        <Card>
          <label className="label">Task description</label>
          <textarea className="field min-h-[90px] text-xs" value={task} onChange={(e) => setTask(e.target.value)} />
          <div className="grid grid-cols-2 gap-3 mt-3">
            <div><label className="label">Avg input tokens</label><input className="field" type="number" value={inTok} onChange={(e) => setInTok(+e.target.value || 0)} /></div>
            <div><label className="label">Avg output tokens</label><input className="field" type="number" value={outTok} onChange={(e) => setOutTok(+e.target.value || 0)} /></div>
          </div>
          <div className="flex flex-wrap gap-2 mt-3">
            {Object.entries(PRESETS).map(([k, v]) => (
              <button key={k} className="btn !py-1.5 !px-3 text-xs" onClick={() => { setTask(v[0]); setInTok(v[1]); setOutTok(v[2]); }}>{k}</button>
            ))}
          </div>
        </Card>

        <Card>
          <div className="text-center">
            <div className="text-5xl font-black tracking-tight">{r.score}</div>
            <div className="text-xs text-slate-400 mt-1">Requires <b>{TIER_LABEL[r.requiredTier]}</b> capability</div>
          </div>
          <div className="h-2.5 rounded-full bg-ink-700 overflow-hidden my-4">
            <div className={"h-full rounded-full " + barColor} style={{ width: r.score + "%" }} />
          </div>
          <div className="space-y-1">
            {r.reasons.map((reason, i) => (
              <div key={i} className="flex justify-between text-xs">
                <span className="text-slate-400">{reason.label}</span>
                <Badge tone={reason.tone === "good" ? "good" : "warn"}>{reason.delta}</Badge>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card>
        <h3 className="text-sm font-semibold mb-3">Ranked by cost for this task</h3>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs text-slate-500 border-b border-line">
              <th className="py-2 font-semibold">Model</th><th className="py-2 font-semibold">Vendor</th>
              <th className="py-2 font-semibold">Capability</th><th className="py-2 font-semibold">Cost / call</th>
              <th className="py-2 font-semibold">Cost / 1M calls</th>
            </tr>
          </thead>
          <tbody>
            {r.ranked.map((c) => {
              const pick = c.model.id === r.recommended?.id;
              return (
                <tr key={c.model.id} className={"border-b border-line/50 " + (pick ? "bg-good/5" : "")}>
                  <td className="py-2 font-semibold">{c.model.name} {pick && <Badge tone="good">★ Routed</Badge>}</td>
                  <td className="py-2 text-slate-400">{c.model.vendor}</td>
                  <td className="py-2">{c.capable ? <Badge tone="brand">{TIER_LABEL[c.model.tier]} ✓</Badge> : <Badge tone="bad">too weak</Badge>}</td>
                  <td className="py-2">{money(c.cost)}</td>
                  <td className="py-2">{money(c.cost * 1e6)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
