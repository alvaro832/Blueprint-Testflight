import { useEffect, useState } from "react";
import { PROVIDERS } from "../lib/api";
import { MODELS } from "../lib/pricing";
import { useStore } from "../lib/store";
import { saveApiKey, getApiKeyPresence, deleteApiKey, wipeAllData, isTauri, setLaunchAtStartup, updateShortcut } from "../lib/bridge";
import { Card, Badge, Toast } from "../components/ui";

export default function Settings() {
  const { settings, setSettings, refreshHistory } = useStore();
  const [presence, setPresence] = useState<Record<string, boolean>>({});
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [toast, setToast] = useState("");

  async function loadPresence() {
    const p: Record<string, boolean> = {};
    for (const prov of PROVIDERS) p[prov.id] = await getApiKeyPresence(prov.id);
    setPresence(p);
  }
  useEffect(() => { loadPresence(); }, []);

  async function save(id: string) {
    const k = (drafts[id] || "").trim();
    if (!k) return;
    await saveApiKey(id, k);
    setDrafts((d) => ({ ...d, [id]: "" }));
    await loadPresence();
    setToast("Key saved securely");
  }
  async function remove(id: string) {
    await deleteApiKey(id);
    await loadPresence();
    setToast("Key removed");
  }

  return (
    <div>
      <header className="mb-5">
        <h1 className="text-2xl font-serif font-medium tracking-tight">Settings</h1>
        <p className="text-sm text-slate-400 mt-0.5">API keys, defaults, and privacy. {isTauri() ? "Keys are encrypted in your OS keychain." : "Web preview: keys are NOT encrypted."}</p>
      </header>

      <Card className="mb-4">
        <h3 className="text-sm font-semibold mb-3">Defaults</h3>
        <div className="grid grid-cols-3 gap-3">
          <div>
            <label className="label">Default model</label>
            <select className="field" value={settings.defaultModelId} onChange={(e) => setSettings({ defaultModelId: e.target.value })}>
              {MODELS.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
            </select>
          </div>
          <div>
            <label className="label">Runs / month</label>
            <input className="field" type="number" min={0} value={settings.monthlyRuns} onChange={(e) => setSettings({ monthlyRuns: Math.max(0, +e.target.value || 0) })} />
          </div>
          <div>
            <label className="label">Compression level</label>
            <select className="field" value={settings.level} onChange={(e) => setSettings({ level: e.target.value as "balanced" | "aggressive" })}>
              <option value="balanced">Balanced (safe)</option>
              <option value="aggressive">Aggressive (also trims examples)</option>
            </select>
          </div>
        </div>
      </Card>

      <Card className="mb-4">
        <h3 className="text-sm font-semibold mb-1">Provider API keys</h3>
        <p className="text-xs text-slate-500 mb-3">Optional — the optimizer works without keys. Connect a provider only for live model-powered rewrites. Keys never appear in logs.</p>
        <div className="space-y-2">
          {PROVIDERS.map((p) => (
            <div key={p.id} className="flex items-center gap-3">
              <div className="w-44 text-sm">
                <div className="font-semibold">{p.label}</div>
                <div className="text-[11px] text-slate-500">{p.docsHint}</div>
              </div>
              {presence[p.id] ? (
                <>
                  <div className="flex-1"><Badge tone="good">Connected</Badge></div>
                  <button className="btn !py-1.5 !px-3 text-xs text-bad" onClick={() => remove(p.id)}>Remove</button>
                </>
              ) : (
                <>
                  <input className="field flex-1 !py-1.5 text-xs" type="password" placeholder={p.keyPlaceholder}
                    value={drafts[p.id] || ""} onChange={(e) => setDrafts((d) => ({ ...d, [p.id]: e.target.value }))} />
                  <button className="btn btn-primary !py-1.5 !px-3 text-xs" onClick={() => save(p.id)}>Save</button>
                </>
              )}
            </div>
          ))}
        </div>
      </Card>

      <Card className="mb-4">
        <h3 className="text-sm font-semibold mb-3">Desktop experience</h3>
        <div className="grid grid-cols-3 gap-3">
          <div>
            <label className="label">Global shortcut</label>
            <input className="field" value={settings.shortcut}
              onChange={(e) => setSettings({ shortcut: e.target.value })}
              onBlur={(e) => updateShortcut(e.target.value.replace(/Ctrl\/Cmd/i, "CmdOrCtrl"))} />
          </div>
          <div>
            <label className="label">Default mode</label>
            <select className="field" value={settings.defaultMode} onChange={(e) => setSettings({ defaultMode: e.target.value as typeof settings.defaultMode })}>
              <option value="auto">Auto (detect)</option>
              <option value="optimize">Optimize</option>
              <option value="compress">Compress</option>
              <option value="reduce">Reduce tokens</option>
              <option value="clarity">Rewrite clearer</option>
            </select>
          </div>
          <div>
            <label className="label">Theme</label>
            <select className="field" value={settings.theme} onChange={(e) => setSettings({ theme: e.target.value as typeof settings.theme })}>
              <option value="dark">Dark</option>
              <option value="light">Light</option>
              <option value="system">System</option>
            </select>
          </div>
        </div>
        <div className="mt-3">
          <label className="label">Accent</label>
          <div className="flex gap-2">
            {(["bronze", "graphite", "ink", "sage"] as const).map((a) => (
              <button key={a} onClick={() => setSettings({ accent: a })}
                aria-label={a}
                className={"w-7 h-7 rounded-full border-2 " + (settings.accent === a ? "border-white" : "border-transparent")}
                style={{ background: { bronze: "#B08D57", graphite: "#9b9aa3", ink: "#6f7d96", sage: "#A6B5A0" }[a] }} />
            ))}
          </div>
        </div>
        <div className="flex flex-col gap-2 mt-4 text-xs">
          <label className="flex items-center gap-2">
            <input type="checkbox" checked={settings.autoCopy} onChange={(e) => setSettings({ autoCopy: e.target.checked })} />
            Auto-copy result after optimizing
          </label>
          <label className="flex items-center gap-2">
            <input type="checkbox" checked={settings.launchAtStartup} onChange={(e) => { setSettings({ launchAtStartup: e.target.checked }); setLaunchAtStartup(e.target.checked); }} />
            Launch at startup
          </label>
          <label className="flex items-center gap-2">
            <input type="checkbox" checked={settings.offline} onChange={(e) => setSettings({ offline: e.target.checked })} />
            Offline mode (never make network calls)
          </label>
        </div>
      </Card>

      <Card className="border-bad/30">
        <h3 className="text-sm font-semibold mb-1">Privacy & data</h3>
        <p className="text-xs text-slate-500 mb-3">Blueprint is local-first. No analytics, no tracking, no account required. Everything stays on this device.</p>
        <label className="flex items-center gap-2 text-xs mb-3">
          <input type="checkbox" checked={settings.telemetry} onChange={(e) => setSettings({ telemetry: e.target.checked })} />
          Share anonymous usage stats (off by default)
        </label>
        <button className="btn text-bad" onClick={async () => {
          if (confirm("Delete ALL local data — history and stored keys? This cannot be undone.")) {
            await wipeAllData(); await loadPresence(); await refreshHistory(); setToast("All local data deleted");
          }
        }}>Delete all my data</button>
      </Card>

      {toast && <Toast msg={toast} onDone={() => setToast("")} />}
    </div>
  );
}
