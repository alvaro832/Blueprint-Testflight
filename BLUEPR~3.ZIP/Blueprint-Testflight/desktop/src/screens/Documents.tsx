import { useState } from "react";
import { optimize, type OptimizeResult } from "../lib/optimizer";
import { useStore } from "../lib/store";
import { addHistory } from "../lib/bridge";
import { Card, Spinner, Empty } from "../components/ui";
import ResultView from "../components/ResultView";

/** Upload .txt/.md/.json/.csv/code files (read locally) and compress their context. */
export default function Documents() {
  const { settings, refreshHistory } = useStore();
  const [text, setText] = useState("");
  const [name, setName] = useState("");
  const [result, setResult] = useState<OptimizeResult | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function onFile(file: File) {
    setError("");
    if (file.size > 2_000_000) {
      setError("File is large (>2MB). For best results, compress sections at a time.");
    }
    try {
      const t = await file.text();
      setText(t);
      setName(file.name);
      setResult(null);
    } catch {
      setError("Could not read that file. Supported: .txt, .md, .json, .csv, code files.");
    }
  }

  async function run() {
    if (!text.trim()) { setError("Upload or paste a document first."); return; }
    setBusy(true); setError("");
    try {
      await new Promise((r) => setTimeout(r, 60));
      const res = optimize(text, { modelId: settings.defaultModelId, monthlyRuns: settings.monthlyRuns, level: "aggressive" });
      setResult(res);
      await addHistory({
        created_at: Date.now(), source: "document", model_id: settings.defaultModelId,
        original_tokens: res.originalTokens, optimized_tokens: res.optimizedTokens,
        saved_usd: res.savedPerCall, quality_risk: res.qualityRisk, preview: (name || "document") + ": " + text.slice(0, 60),
      });
      await refreshHistory();
    } catch {
      setError("Compression failed. Your document was not uploaded anywhere.");
    } finally { setBusy(false); }
  }

  return (
    <div>
      <header className="mb-5">
        <h1 className="text-2xl font-serif font-medium tracking-tight">Documents</h1>
        <p className="text-sm text-slate-400 mt-0.5">Compress long context before you paste it into a model. Uses aggressive mode.</p>
      </header>

      <Card className="mb-4">
        <label
          className="block border-2 border-dashed border-line rounded-xl p-8 text-center cursor-pointer hover:border-brand/60 transition-colors"
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => { e.preventDefault(); if (e.dataTransfer.files[0]) onFile(e.dataTransfer.files[0]); }}
        >
          <input type="file" className="hidden" accept=".txt,.md,.json,.csv,.js,.ts,.py,.html,.xml,.log"
            onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])} />
          <div className="text-3xl mb-2">▢</div>
          <div className="font-semibold text-sm">{name || "Drop a file or click to upload"}</div>
          <div className="text-xs text-slate-500 mt-1">.txt · .md · .json · .csv · code — read locally, never uploaded</div>
        </label>

        {text && (
          <>
            <textarea className="field font-mono text-xs mt-3 min-h-[120px]" value={text} onChange={(e) => setText(e.target.value)} />
            <div className="flex justify-end mt-3 gap-3 items-center">
              {busy && <Spinner label="Compressing…" />}
              <button className="btn btn-primary px-6" onClick={run} disabled={busy}>Compress</button>
            </div>
          </>
        )}
        {error && <div className="text-xs text-warn mt-2">{error}</div>}
      </Card>

      {result ? <ResultView result={result} monthlyRuns={settings.monthlyRuns} /> :
        <Card><Empty title="Compressed document appears here" hint="Upload a file to remove repetition and bloated context while keeping the meaning." icon="🗜️" /></Card>}
    </div>
  );
}
