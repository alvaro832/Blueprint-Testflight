import { useState } from "react";
import { optimize, type OptimizeResult } from "../lib/optimizer";
import { MODELS } from "../lib/pricing";
import { useStore } from "../lib/store";
import { addHistory } from "../lib/bridge";
import { Card, Spinner, Empty } from "../components/ui";
import ResultView from "../components/ResultView";

const SAMPLES: Record<string, string> = {
  "Support reply":
    "I would like you to please carefully read through the following customer support email that we have received from one of our valued customers, and then I want you to write a response. Please make sure that the response is polite and professional in tone. It is very important that you address all of their concerns. Please do not forget to thank them. Thank you so much for your help!",
  "Summarize doc":
    "Please could you read the attached document very carefully and then provide me with a detailed summary of the key points. I would really appreciate it if you could make sure to capture all of the most important information. Thank you very much!",
  "Classify ticket":
    "I want you to act as a support ticket classifier. Please carefully analyze the following support ticket and then tell me which category it belongs to out of these options: Billing, Technical, Account, or Other. Please only respond with the single category name and nothing else.",
};

export default function Optimize() {
  const { settings, refreshHistory } = useStore();
  const [input, setInput] = useState(SAMPLES["Support reply"]);
  const [modelId, setModelId] = useState(settings.defaultModelId);
  const [runs, setRuns] = useState(settings.monthlyRuns);
  const [result, setResult] = useState<OptimizeResult | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function run() {
    setError("");
    if (!input.trim()) {
      setError("Paste a prompt first.");
      return;
    }
    setBusy(true);
    try {
      // optimizer is synchronous & fast; the await keeps the UI responsive for huge inputs
      await new Promise((r) => setTimeout(r, 60));
      const res = optimize(input, { modelId, monthlyRuns: runs, level: settings.level });
      setResult(res);
      await addHistory({
        created_at: Date.now(),
        source: "optimize",
        model_id: modelId,
        original_tokens: res.originalTokens,
        optimized_tokens: res.optimizedTokens,
        saved_usd: res.savedPerMonth || res.savedPerCall,
        quality_risk: res.qualityRisk,
        preview: input.slice(0, 80),
      });
      await refreshHistory();
    } catch (e) {
      setError("Something went wrong while optimizing. Your text was not sent anywhere.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <header className="mb-5">
        <h1 className="text-2xl font-serif font-medium tracking-tight">Optimize Prompt</h1>
        <p className="text-sm text-slate-400 mt-0.5">Paste anything — prompt, email, JSON, code. Blueprint trims the waste and prices the savings. Runs 100% offline.</p>
      </header>

      <Card className="mb-4">
        <div className="flex flex-wrap items-end gap-3 mb-3">
          <div className="flex-1 min-w-[160px]">
            <label className="label">Target model</label>
            <select className="field" value={modelId} onChange={(e) => setModelId(e.target.value)}>
              {MODELS.map((m) => (
                <option key={m.id} value={m.id}>{m.name} ({m.vendor})</option>
              ))}
            </select>
          </div>
          <div className="w-40">
            <label className="label">Runs / month</label>
            <input className="field" type="number" min={0} value={runs} onChange={(e) => setRuns(Math.max(0, +e.target.value || 0))} />
          </div>
          <div className="flex gap-2">
            {Object.keys(SAMPLES).map((k) => (
              <button key={k} className="btn !py-2 !px-3 text-xs" onClick={() => setInput(SAMPLES[k])}>{k}</button>
            ))}
          </div>
        </div>

        <textarea
          className="field font-mono text-xs leading-relaxed min-h-[180px]"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Paste your prompt or text here…"
        />

        <div className="flex items-center justify-between mt-3">
          <div className="text-xs text-slate-500">{input.length.toLocaleString()} chars</div>
          <div className="flex items-center gap-3">
            {busy && <Spinner label="Optimizing…" />}
            <button className="btn btn-primary px-6" onClick={run} disabled={busy}>✦ Optimize</button>
          </div>
        </div>
        {error && <div className="text-xs text-bad mt-2">{error}</div>}
      </Card>

      {result ? (
        <ResultView result={result} monthlyRuns={runs} />
      ) : (
        <Card><Empty title="Your optimized prompt will appear here" hint="Paste text above and press Optimize. Nothing is uploaded — the engine runs locally." /></Card>
      )}
    </div>
  );
}
