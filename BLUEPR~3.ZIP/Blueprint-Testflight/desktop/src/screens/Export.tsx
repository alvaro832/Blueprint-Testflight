import { useEffect } from "react";
import { useStore } from "../lib/store";
import { money } from "../lib/format";
import { copyText } from "../lib/bridge";
import { Card, Empty } from "../components/ui";
import { useState } from "react";
import { Toast } from "../components/ui";

/** Export optimization history as CSV or JSON (downloads locally; no upload). */
export default function ExportScreen() {
  const { history, refreshHistory, totalSaved } = useStore();
  const [toast, setToast] = useState("");
  useEffect(() => { refreshHistory(); }, [refreshHistory]);

  function download(filename: string, content: string, type: string) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = filename; a.click();
    URL.revokeObjectURL(url);
    setToast("Exported " + filename);
  }

  function toCsv() {
    const head = "created_at,source,model_id,original_tokens,optimized_tokens,saved_usd,quality_risk,preview\n";
    const body = history.map((h) =>
      [new Date(h.created_at).toISOString(), h.source, h.model_id, h.original_tokens, h.optimized_tokens,
        h.saved_usd.toFixed(6), h.quality_risk, JSON.stringify(h.preview)].join(",")
    ).join("\n");
    download("blueprint-history.csv", head + body, "text/csv");
  }

  return (
    <div>
      <header className="mb-5">
        <h1 className="text-2xl font-serif font-medium tracking-tight">Export</h1>
        <p className="text-sm text-slate-400 mt-0.5">Download your optimization records. Files are saved locally — nothing is uploaded.</p>
      </header>

      {history.length === 0 ? (
        <Card><Empty title="Nothing to export yet" hint="Run a few optimizations, then export the results as CSV or JSON." icon="↧" /></Card>
      ) : (
        <Card>
          <div className="text-sm mb-4">
            <b>{history.length}</b> records · total saved <b className="text-good">{money(totalSaved)}</b>
          </div>
          <div className="flex gap-3">
            <button className="btn btn-primary" onClick={toCsv}>Export CSV</button>
            <button className="btn" onClick={() => download("blueprint-history.json", JSON.stringify(history, null, 2), "application/json")}>Export JSON</button>
            <button className="btn" onClick={async () => { await copyText(JSON.stringify(history, null, 2)); setToast("Copied JSON"); }}>Copy JSON</button>
          </div>
        </Card>
      )}
      {toast && <Toast msg={toast} onDone={() => setToast("")} />}
    </div>
  );
}
