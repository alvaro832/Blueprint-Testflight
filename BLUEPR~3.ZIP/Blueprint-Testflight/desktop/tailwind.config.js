/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // Graphite (refined dark) — near-monochrome
        ink: { 950: "#0E0E11", 900: "#0E0E11", 850: "#131316", 800: "#191920", 700: "#22222a", 100: "#ECEAE3" },
        line: "#26262e",
        // restrained bronze accent
        brand: { DEFAULT: "#B08D57", dark: "#9A7B4F", soft: "rgba(176,141,87,0.13)" },
        gold: { DEFAULT: "#B08D57", soft: "rgba(176,141,87,0.13)" },
        good: "#A6B5A0",
        warn: "#C9A86A",
        bad: "#C49184",
      },
      fontFamily: {
        serif: ["Fraunces", "Georgia", "Times New Roman", "serif"],
        sans: ["Inter Tight", "-apple-system", "BlinkMacSystemFont", "Segoe UI", "sans-serif"],
        mono: ["JetBrains Mono", "SFMono-Regular", "Menlo", "Consolas", "monospace"],
      },
    },
  },
  plugins: [],
};
